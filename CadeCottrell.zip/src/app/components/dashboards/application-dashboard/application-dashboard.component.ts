import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { APIService } from '../../../services/api.service';
import { LoginTrackerService } from '../../../services/login-tracker.service';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatCheckbox } from '@angular/material/checkbox';
import { userRetrieve } from '../../../models/userRetrieve';
import { applicationRetrieve } from '../../../models/applicationRetrieve';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AppDialogComponent } from '../../dialogs/app-dialog/app-dialog.component';
import { DetailsDialogComponent } from '../../dialogs/details-dialog/details-dialog.component';
import { ModifyDialogComponent } from '../../dialogs/modify-dialog/modify-dialog.component';
import { applicationDetails } from '../../../models/applicationDetails';

@Component({
  selector: 'app-application-dashboard',
  templateUrl: './application-dashboard.component.html',
  styleUrls: ['./application-dashboard.component.css']
})
export class ApplicationDashboardComponent implements OnInit {

  private currentApp: applicationRetrieve = {
    ApplicationName: '',
    ApplicationType: '',
    Technology: '',
    TechnologyVersion: '',
    ServerPlatform: '',
    ServerPlatformVersion: '',
    BusinessUnitName: '',
    BusinessOwnerEmail: '',
    SourceURL: '',
    TreatmentType: ''
  }

 
  //Data for table
  private ELEMENT_DATA: applicationRetrieve[] = [];
  
  //, 'Technology', 'TechVersion', 'ServerPlatform', 'ServerPlatformVersion'
  //Columns
  displayedColumns: string[] = ['ApplicationName', 'ApplicationType', 'BusinessUnitName', 'BusinessOwnerEmail', 'TreatmentType', 'SourceURL', 'Details', 'Modify', 'Delete'];
  dataSource = new MatTableDataSource(this.ELEMENT_DATA);

  //Selection helper
  selection = new SelectionModel<applicationRetrieve>(true, []);

  constructor(private APIService: APIService, public loginTrackerService: LoginTrackerService, private changeDetectorRef: ChangeDetectorRef, public appDialog: MatDialog, public detailsDialog: MatDialog, public modifyDialog: MatDialog) { }

  ngOnInit(): void {
    this.getApplications()
  }

  //Search
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  test(){
    console.log("plz work");
  }

  async deleteApp(email: string, appName: string){
    await this.APIService.deleteApplication("applications", email, appName).toPromise().then(res =>{
      console.log(res);
    }).catch(res =>{
      console.log(res);
    });    

    this.clearTable();
    await this.getApplications();

  }

   openAppDialog(){
    let dialogRef = this.appDialog.open(AppDialogComponent);

    dialogRef.afterClosed().subscribe( async result => {
      console.log(result);
      if(result){
        this.clearTable();
        await this.getApplications();
      }
    });
  }

  openModifyDialog(ApplicationName: string, ApplicationType: string, SourceURL: string, TreatmentType: string, BusinessOwnerEmail: string, BusinessUnitName: string, 
                   Technology: string, TechnologyVersion: string, ServerPlatform: string, ServerPlatformVersion: string){
    
    var app = {
          ApplicationName: ApplicationName,
          ApplicationType: ApplicationType,
          Technology: Technology,
          TechnologyVersion: TechnologyVersion,
          ServerPlatform: ServerPlatform,
          ServerPlatformVersion: ServerPlatformVersion,
          BusinessUnitName: BusinessUnitName,
          BusinessOwnerEmail: BusinessOwnerEmail,
          SourceURL: SourceURL,
          TreatmentType: TreatmentType
          }

                    
    let dialogRef = this.modifyDialog.open(ModifyDialogComponent, {data: app});

    dialogRef.afterClosed().subscribe( async result => {
      console.log(result);
      if(result){
        this.clearTable();
        await this.getApplications();
      }
    });
  }

  openDetailsDialog(applicationName: string, technology: string, technologyVersion: string, serverPlatform: string, serverPlatformVersion: string){

    var appDetails = {
      ApplicationName: applicationName,
      Technology: technology,
      TechnologyVersion: technologyVersion,
      ServerPlatform: serverPlatform,
      ServerPlatformVersion: serverPlatformVersion
    };

    this.detailsDialog.open(DetailsDialogComponent, {data: appDetails});
  }

  //Clears table
  clearTable(){
    this.ELEMENT_DATA.length = 0
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: applicationRetrieve): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.ApplicationName + 1}`;
  }


  async getApplications(){
    if(this.isAdmin()){
      await this.APIService.getAllApplications("applications").toPromise().then(res =>{
        var retrieve = JSON.stringify(res);
        var converted = JSON.parse(retrieve);
  
        for(var i = 0; i < converted.body.Applications.length; i++){
          console.log(converted.body.Applications[i].ApplicationName);
          var app = {
            ApplicationName: converted.body.Applications[i].ApplicationName,
            ApplicationType: converted.body.Applications[i].ApplicationType,
            Technology: converted.body.Applications[i].Technology,
            TechnologyVersion: converted.body.Applications[i].TechnologyVersion,
            ServerPlatform: converted.body.Applications[i].ServerPlatform,
            ServerPlatformVersion: converted.body.Applications[i].ServerPlatformVersion,
            BusinessUnitName: converted.body.Applications[i].BusinessUnitName,
            BusinessOwnerEmail: converted.body.Applications[i].BusinessOwnerEmail,
            SourceURL: converted.body.Applications[i].SourceURL,
            TreatmentType: converted.body.Applications[i].TreatmentType
          }
  
          this.ELEMENT_DATA.push(app);
        }
      }).catch(res =>{
        console.log(res);
      });
    }
    else{
      await this.APIService.getSpecificApplications("applications", this.loginTrackerService.getEmail()).toPromise().then(res =>{
        
        var retrieve = JSON.stringify(res);
        var converted = JSON.parse(retrieve);
        for(var i = 0; i < converted.body.Applications.length; i++){
          console.log(converted.body.Applications[i].ApplicationName);
          var app = {
            ApplicationName: converted.body.Applications[i].ApplicationName,
            ApplicationType: converted.body.Applications[i].ApplicationType,
            Technology: converted.body.Applications[i].Technology,
            TechnologyVersion: converted.body.Applications[i].TechnologyVersion,
            ServerPlatform: converted.body.Applications[i].ServerPlatform,
            ServerPlatformVersion: converted.body.Applications[i].ServerPlatformVersion,
            BusinessUnitName: converted.body.Applications[i].BusinessUnitName,
            BusinessOwnerEmail: converted.body.Applications[i].BusinessOwnerEmail,
            SourceURL: converted.body.Applications[i].SourceURL,
            TreatmentType: converted.body.Applications[i].TreatmentType
          }
          this.ELEMENT_DATA.push(app);
        }

      }).catch(res => {
        console.log(res);
      });
    }

    this.changeDetectorRef.detectChanges();
    this.dataSource._updateChangeSubscription();
  }



  //check login status
  getLoginStatus(){
    return this.loginTrackerService.getLoginStatus();
  }

  //check if admin
  isAdmin(){
    if(this.loginTrackerService.getRole().toUpperCase() == 'ADMIN'){
      return true;
    }

    return false;
  }

}
