import { Component, OnInit, ChangeDetectorRef} from '@angular/core';
import { APIService } from '../../../services/api.service';
import { LoginTrackerService } from '../../../services/login-tracker.service';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatCheckbox } from '@angular/material/checkbox';
import { userRetrieve } from '../../../models/userRetrieve';




@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})

export class UserDashboardComponent implements OnInit {
  
  private currentUser: userRetrieve = {
    firstname: '',
    lastname: '',
    email: '',
    role: ''
  }

  alertSuccess: boolean = false;
  alertFailure: boolean = false;

  //Data for table
  private ELEMENT_DATA: userRetrieve[] = [];
  
  //Columns
  displayedColumns: string[] = ['select', 'Firstname', 'Lastname', 'Email', 'Role'];
  dataSource = new MatTableDataSource(this.ELEMENT_DATA);

  //Selection helper
  selection = new SelectionModel<userRetrieve>(true, []);


  constructor(private APIService: APIService, private loginTrackerService: LoginTrackerService, private changeDetectorRef: ChangeDetectorRef) { }

  //Search
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  //function to delete selected users
    async deleteUser(){
    for(let user of this.selection.selected){
      await this.APIService.delete("users", user.email).toPromise().then(res =>{
        console.log(res);
      }).catch(res =>{
        console.log(res);
        this.alertFailure = true;
      });

      if(this.alertFailure){
        break;
      }
    }
    this.clearTable();
    await this.getUsers();
    this.alertSuccess = true;
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: userRetrieve): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.firstname + 1}`;
  }

 
  //init
  ngOnInit(): void {
    this.getUsers();
  }


  //Get all users and add them to table
  async getUsers(){
    await this.APIService.getAll("users").toPromise().then(res =>{
      var retrieve = JSON.stringify(res);
      var converted = JSON.parse(retrieve);

      for(var i = 0; i < converted.body.Users.length; i++){

        var user = { firstname: converted.body.Users[i].FirstName,
                    lastname: converted.body.Users[i].LastName,
                    email: converted.body.Users[i].Email,
                    role: converted.body.Users[i].Role};

        this.ELEMENT_DATA.push(user);
      }


    }).catch(res =>{
      console.log(res);
    })

    this.changeDetectorRef.detectChanges();
    this.dataSource._updateChangeSubscription();
  }


  clearTable(){
    this.ELEMENT_DATA.length = 0
  }

  //check login status
  getLoginStatus(){
    return this.loginTrackerService.getLoginStatus();
  }

  //check if admin
  isAdmin(){
    if(this.loginTrackerService.getRole().toUpperCase() == 'ADMIN'){
      return true;
    }

    return false;
  }

  matchingEmail(){
    var userEmail = this.loginTrackerService.getEmail();

    if(userEmail == this.selection.selected[0].email){
      this.alertSuccess = true;
    }
    else{
      this.alertFailure = true;
    }

  }

  //close the failure alert
  closeFailureAlert(){
    this.alertFailure = false;
  }

  //close success alert
  closeSuccessAlert(){
    this.alertSuccess = false;
  }
}
