import { Component, OnInit } from '@angular/core';
import { LoginTrackerService } from '../../services/login-tracker.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private loginTrackerService: LoginTrackerService) { }

  ngOnInit(): void {
  }

  getLoginStatus(){
    return this.loginTrackerService.getLoginStatus();
  }

  logout(){
    this.loginTrackerService.setLoginStatus(false);
    localStorage.removeItem("token");
    this.loginTrackerService.deleteUser();
  }

  isAdmin(){
    if(this.loginTrackerService.getRole().toUpperCase() == 'ADMIN'){
      return true;
    }

    return false;
  }

}
