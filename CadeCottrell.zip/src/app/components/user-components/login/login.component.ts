import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from '../../../services/api.service';
import { LoginTrackerService } from '../../../services/login-tracker.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{

  constructor(private APIService: APIService, private loginTrackerService: LoginTrackerService, private router: Router) { }

  async onClickSubmit(data: any){

    await this.APIService.authenticatePost("users/authenticate", data).toPromise().then(res => {
      var retrieve = JSON.stringify(res);
      var converted = JSON.parse(retrieve);

      var token = converted.body.token;

      localStorage.setItem('token', token);
      this.loginTrackerService.setLoginStatus(true);
      this.loginTrackerService.setUser();
      this.router.navigateByUrl('/appDash');
    }).catch(res =>{
      console.log(res);
    });

  }

}
