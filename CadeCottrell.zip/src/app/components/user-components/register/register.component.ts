//import { userRegister } from '../../models/userRegister';
import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { APIService } from '../../../services/api.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{

  alertSuccess: boolean = false;
  alertFailure: boolean = false;

  constructor(private APIService: APIService) {
  }

  onClickSubmit(data: any){
    alert("Entered Email id: " + data.Email + '\n'+
          "Entered Firstname: " + data.FirstName + '\n' +
          "Entered Lastname: " + data.LastName + '\n'+
          "Entered Role: " + data.Role + '\n'+
          "Entered Mobile: " + data.Mobile);
    console.log(data);
    
    this.APIService.post("users", data).toPromise().then(res => {
      console.log(res);
      this.alertSuccess = true;
    }).catch(res =>{
      console.log(res);
      this.alertFailure = true;
    });
  }

  closeSuccessAlert(){
    this.alertSuccess = false;
  }

  closeFailureAlert(){
    this.alertFailure = false;
  }

}
