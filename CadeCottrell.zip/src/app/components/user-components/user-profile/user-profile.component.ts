import { Component, OnInit } from '@angular/core';
import { APIService } from '../../../services/api.service';
import { LoginTrackerService } from '../../../services/login-tracker.service';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  modifyButton: boolean = false;
  alertSuccess: boolean = false;

  constructor(private APIService: APIService, public loginTrackerService: LoginTrackerService) { }

  ngOnInit(): void {
    console.log(this.loginTrackerService.getLastName());
  }

async onClickSubmit(data : any){
  var email = this.loginTrackerService.getEmail();
  console.log("users/" + email);
  await this.APIService.patch("users/" + email, data).toPromise().then(res => {
    var retrieve = JSON.stringify(res);
    var converted = JSON.parse(retrieve); 
    console.log(res);
    console.log(data);

    if(data.Firstname){
      this.loginTrackerService.setFirstName(data.Firstname);
    }

    if(data.Lastname){
      this.loginTrackerService.setLastName(data.Lastname);
    }

    if(data.Role){
      this.loginTrackerService.setRole(data.Role);
    }

    if(data.Email){
      this.loginTrackerService.setEmail(data.Email);
    }

    this.alertSuccess = true;

  }).catch(res =>{
    console.log(res);
  });


}

//check login status
getLoginStatus(){
  return this.loginTrackerService.getLoginStatus();
}

modifyAlertAccess(){
  this.modifyButton = true;
}

modifyAlertDeny(){
  this.modifyButton = false;
}

//close success alert
closeSuccessAlert(){
  this.alertSuccess = false;
}

}
