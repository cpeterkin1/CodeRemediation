import { Component, OnInit } from '@angular/core';
import { APIService } from '../../../services/api.service';


interface TreatmentType {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-app-dialog',
  templateUrl: './app-dialog.component.html',
  styleUrls: ['./app-dialog.component.css']
})


export class AppDialogComponent implements OnInit {

  treatments: TreatmentType[] = [
    {value: 'Remediate', viewValue: 'Remediate'},
    {value: 'Rehost', viewValue: 'Rehost'}
  ];


  constructor(private APIService: APIService) { }

  ngOnInit(): void {
  }

  async onClickSubmit(data : any){
    console.log(data);
    await this.APIService.addApplication("applications", data).toPromise().then( res =>{
      console.log(res);
    })
    .catch(res =>{
      console.log(res);
    });
  }
}
