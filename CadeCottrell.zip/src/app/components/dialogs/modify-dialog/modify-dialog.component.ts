import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { APIService } from '../../../services/api.service';

interface TreatmentType {
  value: string;
  viewValue: string;
}


@Component({
  selector: 'app-modify-dialog',
  templateUrl: './modify-dialog.component.html',
  styleUrls: ['./modify-dialog.component.css']
})
export class ModifyDialogComponent implements OnInit {

  treatments: TreatmentType[] = [
    {value: 'Remediate', viewValue: 'Remediate'},
    {value: 'Rehost', viewValue: 'Rehost'}
  ];

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private APIService: APIService) { }

  public selected = this.data.TreatmentType;

  ngOnInit(): void {
    console.log(this.data);
  }

  async onClickSubmit(modifyData: any){
    var changedData = await this.removeEmptyOrNull(modifyData);
    console.log(changedData);
    await this.APIService.modifyApplication("applications", this.data.BusinessOwnerEmail, this.data.ApplicationName, changedData).toPromise().then(res =>{
      console.log(res);
    })
    .catch(res =>{
      console.log(res);
    });
  }

  async removeEmptyOrNull(data: any){
    if(data.ApplicationName == ''){
      delete data.ApplicationName;
    }

    if(data.ApplicationType == ''){
      delete data.ApplicationType;
    }

    if(data.BusinessUnitName == ''){
      delete data.BusinessUnitName;
    }

    if(data.BusinessOwnerEmail == ''){
      delete data.BusinessOwnerEmail;
    }

    if(data.TreatmentType == ''){
      delete data.TreatmentType;
    }

    if(data.Technology == ''){
      delete data.Technology;
    }

    if(data.TechnologyVersion == ''){
      delete data.TechnologyVersion;
    }

    if(data.ServerPlatform == ''){
      delete data.ServerPlatform;
    }

    if(data.ServerPlatformVersion == ''){
      delete data.ServerPlatformVersion;
    }

    if(data.SourceURL == ''){
      delete data.SourceURL;
    }


    return data;
  }
}
