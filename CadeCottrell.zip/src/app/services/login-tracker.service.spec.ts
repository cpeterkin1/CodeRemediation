import { TestBed } from '@angular/core/testing';

import { LoginTrackerService } from './login-tracker.service';

describe('LoginTrackerService', () => {
  let service: LoginTrackerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginTrackerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
