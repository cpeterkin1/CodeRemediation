import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class APIService {
  readonly ROOT_URL;
  constructor(private httpClient: HttpClient) {
    this.ROOT_URL = "http://localhost:5000";
   }

   //User API
   getAll(uri: string){
     return this.httpClient.get(`${this.ROOT_URL}/${uri}`);
   }

   get(uri: string, email: string){
     return this.httpClient.get(`${this.ROOT_URL}/${uri}/${email}`);
   }

   post(uri: string, payload: Object){
     return this.httpClient.post(`${this.ROOT_URL}/${uri}`, payload);
   }

   patch(uri: string, payload: Object){
    return this.httpClient.patch(`${this.ROOT_URL}/${uri}`, payload);
   }

   authenticatePost(uri: string, payload: Object){
    return this.httpClient.post(`${this.ROOT_URL}/${uri}`, payload);
  }

  delete(uri: string, email: string){
    return this.httpClient.delete(`${this.ROOT_URL}/${uri}/${email}`);
  }

  //Application API
  getAllApplications(uri: string){
    return this.httpClient.get(`${this.ROOT_URL}/${uri}`);
  }

  getSpecificApplications(uri: string, email: string){
    return this.httpClient.get(`${this.ROOT_URL}/${uri}/${email}`);
  }

  deleteApplication(uri: string, email: string, applicationName: string){
    return this.httpClient.delete(`${this.ROOT_URL}/${uri}/${email}/${applicationName}`);
  }

  addApplication(uri: string, payload: Object){
    return this.httpClient.post(`${this.ROOT_URL}/${uri}`, payload);
  }

  modifyApplication(uri: string, email: string, applicationName: string, payload: Object){
    return this.httpClient.patch(`${this.ROOT_URL}/${uri}/${email}/${applicationName}`, payload);
  }

}
