import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { userRetrieve } from '../models/userRetrieve';

@Injectable({
  providedIn: 'root'
})
export class LoginTrackerService {

  private loggedIn: boolean = false;
  private helper: any = new JwtHelperService(); 

  private currentUser: userRetrieve = {
    firstname: '',
    lastname: '',
    email: '',
    role: ''
  }

  constructor() { }

  setLoginStatus(data: boolean){
    this.loggedIn = data;
  }

  getLoginStatus(){
    return this.loggedIn;
  }

  setUser(){
    var token = localStorage.getItem('token');
    var decodedToken = this.helper.decodeToken(token);

    this.currentUser.firstname = decodedToken.firstname;
    this.currentUser.lastname = decodedToken.lastname;
    this.currentUser.email = decodedToken.email;
    this.currentUser.role = decodedToken.role;
  }

  deleteUser(){
    this.currentUser.firstname = '';
    this.currentUser.lastname = '';
    this.currentUser.email = '';
    this.currentUser.role = '';
  }

  getRole(){
    return this.currentUser.role;
  }

  getEmail(){
    return this.currentUser.email;
  }

  getFirstName(){
    return this.currentUser.firstname;
  }

  getLastName(){
    return this.currentUser.lastname;
  }

  setRole(role : any){
    this.currentUser.role = role;
  }

  setEmail(email : any){
    this.currentUser.email = email;
  }

  setFirstName(firstname : any){
    this.currentUser.firstname = firstname;
  }

  setLastName(lastname : any){
    this.currentUser.lastname = lastname;
  }

}
