export interface applicationDetails {
    Technology: string;
    TechnologyVersion: string;
    ServerPlatform: string;
    ServerPlatformVersion: string;
}