export interface userRetrieve {
    firstname: string;
    lastname: string;
    email: string;
    role: string;
}